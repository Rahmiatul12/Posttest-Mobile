import 'package:flutter/material.dart';
import 'package:posttest5_rahmiatulmawaddah_2009106076/halaman1.dart';
import 'package:posttest5_rahmiatulmawaddah_2009106076/profile.dart';

import 'earphone.dart';
import 'handphone.dart';
import 'jam.dart';
import 'laptop.dart';
import 'main.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: electronic(),
    );
  }
}

Widget myContainer1() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(255, 26, 26, 26),
      image: DecorationImage(
        image: AssetImage('produk/1.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 108, 105, 105),
          offset: Offset(1, 1),
          blurRadius: 1,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'Baru',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 0, 89, 244),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite_border,
          color: Color.fromARGB(255, 0, 0, 255),
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' HandPhone \n Rp.1.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer2() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromRGBO(228, 174, 197, 1),
      image: DecorationImage(
        image: AssetImage('produk/2.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 97, 96, 96),
          offset: Offset(1, 1),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'New',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 55, 255, 55),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite_border,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' HandPhone \n Rp.4.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer3() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(235, 9, 9, 9),
      image: DecorationImage(
        image: AssetImage('produk/3.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'New',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 55, 255, 55),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite_border,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' Headset  \n Rp.200.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer4() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromRGBO(228, 174, 197, 1),
      image: DecorationImage(
        image: AssetImage('produk/4.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'New',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 55, 255, 55),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite_border,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' Jam Tangan \n Rp.150.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer5() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(235, 0, 0, 0),
      image: DecorationImage(
        image: AssetImage('produk/5.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 252, 251, 251),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'New',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 55, 255, 55),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite_border,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' Jam Tangan \n Rp.150.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer6() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(235, 255, 255, 255),
      image: DecorationImage(
        image: AssetImage('produk/6.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(1, 1),
          blurRadius: 10,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'Discount 50%',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 8, 8, 8),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite_border,
          color: Color.fromARGB(255, 255, 0, 0),
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text('Mesin Cuci  \n Rp.5.560.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 0, 0, 0),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Color.fromARGB(255, 0, 0, 0),
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer7() {
  return Container(
    width: 200,
    height: 300,
    margin: EdgeInsets.only(top: 20, left: 10, bottom: 20),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(235, 0, 145, 255),
      image: DecorationImage(
        image: AssetImage('produk/7.png'),
      ),
      boxShadow: [
        BoxShadow(
          color: Color.fromARGB(255, 0, 0, 0),
          offset: Offset(1, 1),
          blurRadius: 5,
        ),
      ],
    ),
    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'New',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 55, 255, 55),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite_border,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' HS Gaming \n Rp.1.500.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget myContainer8() {
  return Container(
    width: 200,
    height: 300,
    margin: const EdgeInsets.only(top: 20, left: 10, bottom: 20),
    //child: Image.asset('img/1.png'),

    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(15),
      color: Color.fromARGB(235, 0, 0, 0),
      image: const DecorationImage(
        image: AssetImage('produk/8.png'),
      ),
      boxShadow: const [
        BoxShadow(
          color: Color.fromARGB(255, 255, 255, 255),
          offset: Offset(0, 0),
          blurRadius: 10,
        ),
      ],
    ),

    child: Stack(children: [
      Container(
        width: 175,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: Colors.transparent,
        ),
      ),
      Container(
        padding: EdgeInsets.only(top: 6, left: 6),
        child: Text(
          'New',
          style: TextStyle(
            fontSize: 15,
            color: Color.fromARGB(255, 55, 255, 55),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      Container(
        alignment: Alignment.topRight,
        padding: EdgeInsets.only(top: 6, right: 5),
        child: Icon(
          Icons.favorite_border,
          color: Colors.white,
          size: 30,
        ),
      ),
      Container(
        alignment: Alignment.bottomLeft,
        padding: EdgeInsets.only(bottom: 15, left: 8),
        child: Text(' I Pods 7 \n Rp.500.000',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontWeight: FontWeight.bold,
              fontSize: 15,
              color: Color.fromARGB(255, 255, 255, 255),
            )),
      ),
      Container(
        alignment: Alignment.bottomRight,
        padding: EdgeInsets.only(bottom: 15, right: 8),
        child: Icon(
          Icons.add_shopping_cart,
          color: Colors.white,
          size: 30,
        ),
      )
    ]),
  );
}

Widget Bawah2() {
  return Container(
    margin: EdgeInsets.only(top: 15),
    child: Text(' Popular ',
        textAlign: TextAlign.left,
        style: TextStyle(
          fontFamily: 'Bookman',
          fontSize: 18,
          fontWeight: FontWeight.bold,
          color: Color.fromARGB(235, 0, 0, 0),
        )),
  );
}

Widget Judul() {
  return Container(
    alignment: Alignment.topCenter,
    margin: EdgeInsets.only(top: 10),
    child: Text(
      "Electronic Goods",
      style: TextStyle(
        fontSize: 50,
        fontWeight: FontWeight.bold,
        fontFamily: 'cursive',
        color: Color.fromARGB(235, 240, 148, 148),
        shadows: [
          Shadow(
            color: Color.fromARGB(255, 0, 0, 0),
            offset: Offset(1, 1),
            blurRadius: 5,
          ),
        ],
      ),
    ),
  );
}

Widget Box() {
  return Container(
    transformAlignment: Alignment.bottomCenter,
    padding: EdgeInsets.only(bottom: 10, top: 20, left: 20),
    child: Row(
      children: <Widget>[
        Container(
            child: Row(children: <Widget>[
          Container(
            child: Container(
              margin: EdgeInsets.only(left: 20),
              width: 290,
              height: 40,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Color.fromARGB(255, 139, 137, 137),
                    offset: Offset(1, 1),
                    blurRadius: 5,
                  ),
                ],
              ),
              child: TextField(
                textAlign: TextAlign.center,
                onChanged: (value) {},
                decoration: InputDecoration(
                    hintText: 'Type Search for Keyword ',
                    hintStyle:
                        TextStyle(color: Color.fromARGB(255, 41, 38, 38)),
                    suffixIcon: Icon(Icons.search)),
              ),
            ),
          ),
          Container(
            margin: EdgeInsets.only(left: 20),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(10),
              color: Color.fromARGB(235, 249, 246, 246),
              boxShadow: [
                BoxShadow(
                  color: Color.fromARGB(255, 0, 0, 0),
                  offset: Offset(1, 1),
                  blurRadius: 5,
                ),
              ],
            ),
            child: Icon(
              Icons.undo,
              color: Color.fromRGBO(57, 55, 55, 1),
              size: 30,
            ),
          ),
        ])),
      ],
    ),
  );
}

Widget Myicon(BuildContext context) {
  return Container(
    child: Row(children: [
      Container(
        margin: EdgeInsets.only(left: 20, top: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Color.fromARGB(235, 255, 255, 255),
          boxShadow: [
            BoxShadow(
              color: Color.fromARGB(255, 177, 171, 171),
              offset: Offset(2, 2),
              blurRadius: 5,
            ),
          ],
        ),
        child: Row(children: [
          Container(
            margin: EdgeInsets.only(left: 0, right: 0),
            child: IconButton(
              icon: Icon(
                Icons.window,
                color: Color.fromARGB(235, 255, 149, 149),
                size: 25,
              ),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return electronic();
                }));
              },
            ),
          ),
          Container(
              margin: EdgeInsets.only(left: 0, right: 10),
              child: Text('all',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 18,
                    color: Color.fromARGB(235, 255, 149, 149),
                  ))),
        ]),
      ),
      Container(
        margin: EdgeInsets.only(left: 20, top: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Color.fromARGB(235, 255, 255, 255),
          boxShadow: [
            BoxShadow(
              color: Color.fromARGB(255, 139, 137, 137),
              offset: Offset(1, 1),
              blurRadius: 5,
            ),
          ],
        ),
        child: Row(children: [
          Container(
            margin: EdgeInsets.only(left: 0, right: 0),
            child: IconButton(
              icon: Icon(
                Icons.laptop,
                color: Color.fromARGB(235, 82, 80, 80),
                size: 25,
              ),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return laptop();
                }));
              },
            ),
          ),
          Container(
              margin: EdgeInsets.only(left: 0, right: 10),
              child: Text('Laptop',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 15,
                    color: Color.fromARGB(235, 65, 63, 63),
                  ))),
        ]),
      ),
      Container(
        margin: EdgeInsets.only(left: 20, top: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Color.fromARGB(235, 255, 255, 255),
          boxShadow: [
            BoxShadow(
              color: Color.fromARGB(255, 139, 137, 137),
              offset: Offset(1, 5),
              blurRadius: 5,
            ),
          ],
        ),
        child: Row(children: [
          Container(
            margin: EdgeInsets.only(left: 0, right: 0),
            child: IconButton(
              icon: Icon(
                Icons.timer,
                color: Color.fromARGB(235, 0, 0, 0),
                size: 25,
              ),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return televisi();
                }));
              },
            ),
          ),
          Container(
              margin: EdgeInsets.only(left: 0, right: 10),
              child: Text('Jam ',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 15,
                    color: Color.fromARGB(235, 33, 31, 31),
                  ))),
        ]),
      ),
      Container(
        margin: EdgeInsets.only(left: 20, top: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Color.fromARGB(235, 255, 255, 255),
          boxShadow: [
            BoxShadow(
              color: Color.fromARGB(255, 139, 137, 137),
              offset: Offset(1, 1),
              blurRadius: 5,
            ),
          ],
        ),
        child: Row(children: [
          Container(
            margin: EdgeInsets.only(left: 0, right: 0),
            child: IconButton(
              icon: Icon(
                Icons.headset,
                color: Color.fromARGB(235, 111, 111, 111),
                size: 25,
              ),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return earphone();
                }));
              },
            ),
          ),
          Container(
              margin: EdgeInsets.only(left: 0, right: 10),
              child: Text('earphone',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 15,
                    color: Color.fromARGB(235, 58, 53, 53),
                  ))),
        ]),
      ),
      Container(
        margin: EdgeInsets.only(left: 20, top: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Color.fromARGB(235, 255, 255, 255),
          boxShadow: [
            BoxShadow(
              color: Color.fromARGB(255, 139, 137, 137),
              offset: Offset(1, 1),
              blurRadius: 5,
            ),
          ],
        ),
        child: Row(children: [
          Container(
            margin: EdgeInsets.only(left: 0, right: 0),
            child: IconButton(
              icon: Icon(
                Icons.phone_iphone,
                color: Color.fromARGB(235, 70, 69, 69),
                size: 25,
              ),
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return handpone();
                }));
              },
            ),
          ),
          Container(
              margin: EdgeInsets.only(left: 0, right: 10),
              child: Text('Handphone',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 15,
                    color: Color.fromARGB(235, 71, 63, 63),
                  ))),
        ]),
      ),
    ]),
  );
}

Widget boxed() {
  return Container(
    child: Container(
      margin: EdgeInsets.only(right: 10, top: 20),
      width: 350,
      height: 150,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Color.fromARGB(235, 95, 218, 168),
          Color.fromARGB(255, 187, 85, 227),
        ]),
        image: DecorationImage(
            alignment: Alignment.topRight,
            image: AssetImage('produk/digital1.png')),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Color.fromARGB(255, 139, 137, 137),
            offset: Offset(0, 5),
            blurRadius: 5,
          ),
        ],
      ),
      child: Stack(children: [
        Container(
          width: 175,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.transparent,
          ),
          child: Container(
            padding: EdgeInsets.only(left: 10, top: 10),
            child: Container(
              child: Text(
                " Get the Special Discont ",
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 20, left: 30),
          child: Text(
            '50%',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontSize: 70,
              color: Color.fromARGB(255, 255, 255, 255),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 90, left: 35),
          child: Text('OFF',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 50,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
      ]),
    ),
  );
}

Widget boxed1() {
  return Container(
    child: Container(
      margin: EdgeInsets.only(right: 10, top: 20),
      width: 350,
      height: 150,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Color.fromARGB(255, 75, 52, 245),
          Color.fromARGB(235, 0, 255, 153),
        ]),
        image: DecorationImage(
            alignment: Alignment.topRight, image: AssetImage('produk/9.png')),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Color.fromARGB(255, 139, 137, 137),
            offset: Offset(0, 5),
            blurRadius: 5,
          ),
        ],
      ),
      child: Stack(children: [
        Container(
          width: 175,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.transparent,
          ),
          child: Container(
            padding: EdgeInsets.only(left: 10, top: 10),
            child: Container(
              child: Text(
                " Get the Special Discont ",
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 20, left: 30),
          child: Text(
            '50%',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontSize: 70,
              color: Color.fromARGB(255, 255, 255, 255),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 90, left: 35),
          child: Text('OFF',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 50,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
      ]),
    ),
  );
}

Widget boxed2() {
  return Container(
    child: Container(
      margin: EdgeInsets.only(right: 10, top: 20),
      width: 350,
      height: 150,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Color.fromARGB(255, 119, 255, 0),
          Color.fromARGB(235, 231, 100, 132),
        ]),
        image: DecorationImage(
            alignment: Alignment.topRight, image: AssetImage('produk/10.png')),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Color.fromARGB(255, 139, 137, 137),
            offset: Offset(0, 5),
            blurRadius: 5,
          ),
        ],
      ),
      child: Stack(children: [
        Container(
          width: 175,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.transparent,
          ),
          child: Container(
            padding: EdgeInsets.only(left: 10, top: 10),
            child: Container(
              child: Text(
                " Get the Special Discont ",
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 20, left: 30),
          child: Text(
            '50%',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontSize: 70,
              color: Color.fromARGB(255, 255, 255, 255),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 90, left: 35),
          child: Text('OFF',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 50,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
      ]),
    ),
  );
}

Widget boxed3() {
  return Container(
    child: Container(
      margin: EdgeInsets.only(right: 10, top: 20),
      width: 350,
      height: 150,
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [
          Color.fromARGB(255, 187, 85, 227),
          Color.fromARGB(235, 95, 218, 168),
        ]),
        image: DecorationImage(
            alignment: Alignment.centerRight,
            image: AssetImage('produk/11.png')),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Color.fromARGB(255, 139, 137, 137),
            offset: Offset(0, 5),
            blurRadius: 5,
          ),
        ],
      ),
      child: Stack(children: [
        Container(
          width: 175,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: Colors.transparent,
          ),
          child: Container(
            padding: EdgeInsets.only(left: 10, top: 10),
            child: Container(
              child: Text(
                " Get the Special Discont ",
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Color.fromARGB(255, 255, 255, 255),
                ),
              ),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 20, left: 30),
          child: Text(
            '50%',
            style: TextStyle(
              fontFamily: 'san-serif',
              fontSize: 70,
              color: Color.fromARGB(255, 255, 255, 255),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.only(top: 90, left: 35),
          child: Text('OFF',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 50,
                color: Color.fromARGB(255, 255, 255, 255),
              )),
        ),
      ]),
    ),
  );
}

class electronic extends StatelessWidget {
  const electronic({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;

    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return halaman1();
              }));
            },
            color: Color.fromARGB(255, 236, 154, 154),
          ),
          title: const Text('Rahmiatul'),
          titleTextStyle: TextStyle(
            fontFamily: 'cursive',
            fontSize: 28,
            color: Color.fromARGB(247, 4, 4, 4),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.shopping_bag),
              color: Color.fromARGB(255, 19, 18, 18),
              onPressed: () {},
            ),
            IconButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return profile();
                }));
              },
              icon: Icon(Icons.person),
              color: Colors.black,
            ),
          ],
          backgroundColor: Color.fromARGB(247, 254, 251, 251),
        ),
        body: Container(
          alignment: Alignment.topLeft,
          width: lebar,
          height: tinggi,
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [
              Color.fromARGB(255, 255, 255, 255),
              Color.fromARGB(235, 255, 255, 255),
            ]),
          ),
          child: ListView(
            children: <Widget>[
              Judul(),
              Box(),
              Container(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Container(
                    child: Row(
                      children: [
                        boxed(),
                        boxed1(),
                        boxed2(),
                        boxed3(),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Container(
                    child: Row(
                      children: [
                        Myicon(context),
                      ],
                    ),
                  ),
                ),
              ),
              Container(
                  alignment: Alignment.bottomLeft,
                  child: Column(
                    children: [
                      Bawah2(),
                    ],
                  )),
              Container(
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Container(
                    child: Row(
                      children: [
                        myContainer1(),
                        myContainer2(),
                        myContainer3(),
                        myContainer4(),
                        myContainer5(),
                        myContainer6(),
                        myContainer7(),
                        myContainer8(),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
