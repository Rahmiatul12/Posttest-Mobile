import 'package:flutter/material.dart';
import 'package:posttest5_rahmiatulmawaddah_2009106076/Settings.dart';
import 'package:posttest5_rahmiatulmawaddah_2009106076/detail.dart';
import 'package:posttest5_rahmiatulmawaddah_2009106076/detail2.dart';
import 'package:posttest5_rahmiatulmawaddah_2009106076/detail3.dart';
import 'package:posttest5_rahmiatulmawaddah_2009106076/halaman2.dart';
import 'package:posttest5_rahmiatulmawaddah_2009106076/main.dart';

class halaman1 extends StatelessWidget {
  const halaman1({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var appBar2 = AppBar(
      elevation: 0,
      title: Text('Hi, User ',
          style: TextStyle(
            fontFamily: 'san-serif',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color.fromARGB(255, 255, 255, 255),
          )),
      // actions: [Image.asset('produk/rahmi.png')],
      bottom: TabBar(
          tabs: [Tab(text: 'Home'), Tab(text: 'Chats'), Tab(text: 'Settings')]),
      backgroundColor: Color.fromARGB(255, 241, 182, 239),
    );
    var drawer2 = Drawer(
      child: ListView(
        children: <Widget>[
          ListTile(
            title: Text('Menu Goods'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => electronic(),
                  ));
            },
          ),
          ListTile(
            title: Text('Logout'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MyHomePage(),
                  ));
            },
          ),
        ],
      ),
    );
    return DefaultTabController(
        length: 3,
        child: Scaffold(
          drawer: drawer2,
          appBar: appBar2,
          body: TabBarView(
            children: [
              Container(
                  child: Column(
                children: [
                  tabar(),
                ],
              )),
              Container(
                  child: Column(
                children: [
                  header(),
                  title(),
                  chat(),
                  chat1(),
                  chat2(),
                  chat3(),
                  chat4(),
                  chat5(),
                  chat6(),
                  chat7(),
                  chat8(),
                ],
              )),
              Container(
                child: Column(
                  children: [
                    Set(),
                  ],
                ),
              ),
            ],
          ),
        ));
  }
}

Widget poto0(BuildContext context) {
  return Container(
      child: Container(
          width: 350,
          height: 130,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 255, 111, 250),
                offset: Offset(9, 0),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.topRight,
              image: AssetImage(
                'produk/1.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              margin: EdgeInsets.only(top: 20),
              alignment: Alignment.topLeft,
              child: Text('Hp keluaran terbaru \n dan dengan harga terjangkau',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 0, 0, 0),
                  )),
            ),
            Container(
              margin: EdgeInsets.only(top: 40),
              child: Row(
                children: [
                  Container(
                    child: SizedBox(
                      width: 85,
                      height: 34,
                      child: FlatButton(
                          color: Color.fromARGB(255, 255, 111, 250),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) {
                              return halamandet();
                            }));
                          },
                          child: Text(
                            'detail',
                            style: TextStyle(
                                color: Color.fromARGB(255, 255, 255, 255)),
                          )),
                    ),
                  ),
                ],
              ),
            ),
          ])));
}

Widget poto1(BuildContext context) {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 50),
          width: 350,
          height: 130,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 255, 111, 250),
                offset: Offset(9, 0),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.topRight,
              image: AssetImage(
                'produk/5.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              margin: EdgeInsets.only(top: 20),
              alignment: Alignment.topLeft,
              child: Text(
                  'Jam Tangan keluaran terbaru \n dan dengan harga terjangkau',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 0, 0, 0),
                  )),
            ),
            Container(
              margin: EdgeInsets.only(top: 40),
              child: Row(
                children: [
                  Container(
                    child: SizedBox(
                      width: 85,
                      height: 34,
                      child: FlatButton(
                          color: Color.fromARGB(255, 255, 111, 250),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) {
                              return halamandet2();
                            }));
                          },
                          child: Text(
                            'detail',
                            style: TextStyle(
                                color: Color.fromARGB(255, 255, 255, 255)),
                          )),
                    ),
                  ),
                ],
              ),
            ),
          ])));
}

Widget poto2(BuildContext context) {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 50),
          width: 350,
          height: 130,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 255, 111, 250),
                offset: Offset(9, 0),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.topRight,
              image: AssetImage(
                'produk/3.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              margin: EdgeInsets.only(top: 20),
              alignment: Alignment.topLeft,
              child: Text(
                  'Headset keluaran terbaru \n dan dengan harga terjangkau',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 15,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 46, 44, 44),
                  )),
            ),
            Container(
              margin: EdgeInsets.only(top: 40),
              child: Row(
                children: [
                  Container(
                    child: SizedBox(
                      width: 85,
                      height: 34,
                      child: FlatButton(
                          color: Color.fromARGB(255, 255, 111, 250),
                          onPressed: () {
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) {
                              return halamandet3();
                            }));
                          },
                          child: Text(
                            'detail',
                            style: TextStyle(
                                color: Color.fromARGB(255, 255, 255, 255)),
                          )),
                    ),
                  ),
                ],
              ),
            ),
          ])));
}

class tabar extends StatelessWidget {
  const tabar({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(children: [
        header(),
        title1(),
        poto0(context),
        poto1(context),
        poto2(context),
      ]),
    );
  }
}

class title extends StatelessWidget {
  const title({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 30,
        child: Stack(
          children: [
            Row(children: [
              Container(
                margin: EdgeInsets.only(left: 10),
                alignment: Alignment.centerLeft,
                child: Text('Chats',
                    style: TextStyle(
                        shadows: [
                          Shadow(
                            blurRadius: 10,
                            color: Colors.black,
                            offset: Offset(1, 1),
                          ),
                        ],
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 255, 111, 250))),
              ),
              Spacer(),
              Positioned(
                child: Container(
                  margin: EdgeInsets.only(right: 10),
                  height: 30,
                  width: 60,
                  decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Color.fromARGB(255, 6, 6, 6),
                          blurRadius: 7,
                          offset: Offset(0, 5),
                        )
                      ],
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('all',
                        style: TextStyle(
                            fontSize: 15,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              )
            ])
          ],
        ));
  }
}

class title1 extends StatelessWidget {
  const title1({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(bottom: 20),
        height: 30,
        child: Stack(
          children: [
            Row(children: [
              Container(
                margin: EdgeInsets.only(
                  left: 10,
                ),
                alignment: Alignment.centerLeft,
                child: Text('Latest',
                    style: TextStyle(
                        shadows: [
                          Shadow(
                            blurRadius: 10,
                            color: Color.fromARGB(255, 255, 111, 250),
                            offset: Offset(1, 1),
                          ),
                        ],
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0))),
              ),
              Spacer(),
            ])
          ],
        ));
  }
}

class header extends StatelessWidget {
  const header({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        margin: EdgeInsets.only(bottom: 0),
        child: Column(children: [
          Container(
            height: MediaQuery.of(context).size.height / 15,
            child: Stack(
              children: [
                Container(
                  height: MediaQuery.of(context).size.height / 8,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(30),
                      bottomRight: Radius.circular(30),
                    ),
                    color: Color.fromARGB(255, 241, 182, 239),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 30,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(30),
                        topRight: Radius.circular(30),
                      ),
                      color: Color.fromARGB(255, 255, 255, 255),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ]));
  }
}

Widget chat() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 30),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/1.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Tika',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 230, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('2',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Typing....',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('20:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat1() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/memed.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Fara',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 235, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('1',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Kapan Barang Di Kirim...',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('01:07',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat2() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/dendeng.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Denissa',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 210, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('5',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Kirim Barang...',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('19:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat3() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/nanda.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Nanda',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 220, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('1',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Cek Harga....',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('13:15',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat4() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/1.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Rista',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 230, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('3',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Warna Apa Aja...',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('10:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat5() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/leha.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Sholeha',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 210, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('3',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Merk Lain Adakah....',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('20:19',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat6() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/nada.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Nada',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 230, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('4',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Kulkas 2 Pintu....',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('20:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat7() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/alin.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Alin',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 240, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('6',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Typing....',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('10:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat8() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/putri.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Putri',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 230, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('2',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Laptop Acer Ada kah....',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('21:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}

Widget chat9() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 5),
          width: 350,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
            image: DecorationImage(
              alignment: Alignment.centerLeft,
              image: AssetImage(
                'produk/1.png',
              ),
            ),
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 50),
                  alignment: Alignment.centerLeft,
                  child: Text('Putri',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 220, top: 5),
                  height: 25,
                  width: 25,
                  decoration: BoxDecoration(
                      color: Color.fromARGB(255, 255, 111, 250),
                      borderRadius: BorderRadius.circular(20)),
                  child: TextButton(
                    onPressed: () {},
                    child: Text('2',
                        style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Roboto',
                            color: Color.fromARGB(255, 255, 255, 255))),
                  ),
                ),
              ]),
            ),
            Container(
              alignment: Alignment.centerLeft,
              margin: EdgeInsets.only(left: 50),
              child: Text('Typing....',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 82, 77, 77),
                  )),
            ),
            Container(
              alignment: Alignment.bottomRight,
              margin: EdgeInsets.only(right: 20),
              child: Text('20:21',
                  style: TextStyle(
                    fontFamily: 'san-serif',
                    fontSize: 8,
                    fontWeight: FontWeight.bold,
                    color: Color.fromARGB(255, 90, 85, 85),
                  )),
            ),
          ])));
}
