package com.rahmi.pertemuan7_crud

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
