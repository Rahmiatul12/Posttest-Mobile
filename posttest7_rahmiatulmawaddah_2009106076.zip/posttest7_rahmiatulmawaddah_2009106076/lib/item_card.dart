import 'package:flutter/material.dart';
import 'package:pertemuan7_crud/halaman1.dart';

import 'package:pertemuan7_crud/main.dart';
import 'package:pertemuan7_crud/main_page.dart';

class ItemCard extends StatelessWidget {
  final String nama;
  final String ttl;
  final String alamat;
  final String email;
  final int noHp;
  //// Pointer to Update Function
  final Function? onUpdate;
  //// Pointer to Delete Function
  final Function? onDelete;

  ItemCard(this.nama, this.email, this.alamat, this.ttl, this.noHp,
      {this.onUpdate, this.onDelete});

  get index => null;

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              Container(
                alignment: Alignment.centerLeft,
                margin: EdgeInsets.only(left: 10),
                child: IconButton(
                  icon: Icon(Icons.arrow_back),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) {
                      return halaman1();
                    }));
                  },
                ),
              ),
              boxed4(),
              Container(
                margin: EdgeInsets.only(bottom: 10),
                alignment: Alignment.centerLeft,
                height: 60,
                width: 400,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border:
                        Border.all(color: Color.fromARGB(255, 63, 245, 63))),
                child: Text(
                  "Nama : $nama",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 10),
                alignment: Alignment.centerLeft,
                height: 60,
                width: 400,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border:
                        Border.all(color: Color.fromARGB(255, 63, 245, 63))),
                child: Text(
                  "TTL : $ttl",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 10),
                alignment: Alignment.centerLeft,
                height: 60,
                width: 400,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border:
                        Border.all(color: Color.fromARGB(255, 63, 245, 63))),
                child: Text(
                  "Alamat : $alamat",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
              Container(
                margin: EdgeInsets.only(bottom: 10),
                alignment: Alignment.centerLeft,
                height: 60,
                width: 400,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border:
                        Border.all(color: Color.fromARGB(255, 63, 245, 63))),
                child: Text(
                  "Email : $email",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
              Container(
                alignment: Alignment.centerLeft,
                height: 60,
                width: 400,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    border:
                        Border.all(color: Color.fromARGB(255, 63, 245, 63))),
                child: Text(
                  "No Hp : $noHp",
                  style: TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 16,
                  ),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(left: 100, top: 20),
                child: SizedBox(
                  height: 40,
                  width: 60,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: Color.fromARGB(255, 0, 24, 95),
                      ),
                      child:
                          Text("Edit", style: TextStyle(color: Colors.white)),
                      onPressed: () {
                        if (onUpdate != null) onUpdate!();
                      }),
                ),
              ),
              Container(
                margin: EdgeInsets.only(right: 100, top: 20, left: 10),
                child: SizedBox(
                  height: 40,
                  width: 80,
                  child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: Color.fromARGB(255, 0, 24, 95),
                      ),
                      child:
                          Text("Delete", style: TextStyle(color: Colors.white)),
                      onPressed: () {
                        if (onDelete != null) onDelete!();
                      }),
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}

Widget boxed4() {
  return Container(
    alignment: Alignment.center,
    child: Container(
      margin: EdgeInsets.only(
        top: 2,
      ),
      width: 400,
      height: 170,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Stack(children: [
        Container(
          alignment: Alignment.topCenter,
          child: Text('Electronic Goods',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 0, 0, 0),
              )),
        ),
        Container(
          alignment: Alignment.topCenter,
          margin: EdgeInsets.only(top: 30),
          child: Text('Hi,your profile',
              style: TextStyle(
                fontFamily: 'cursive',
                fontSize: 50,
                color: Color.fromARGB(255, 0, 0, 0),
              )),
        ),
      ]),
    ),
  );
}
