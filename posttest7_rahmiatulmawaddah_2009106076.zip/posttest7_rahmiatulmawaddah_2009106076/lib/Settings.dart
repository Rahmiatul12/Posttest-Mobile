import 'package:flutter/material.dart';

import 'halaman2.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: const Set(),
    );
  }
}

class Set extends StatefulWidget {
  const Set({Key? key}) : super(key: key);

  @override
  State<Set> createState() => _Set();
}

Widget chat() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 1),
          width: 400,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 10),
                  alignment: Alignment.centerLeft,
                  child: Text('Profile Saya',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 265, top: 5),
                  height: 25,
                  width: 25,
                  child: IconButton(
                    icon: Icon(Icons.arrow_forward_ios),
                    onPressed: () {},
                  ),
                ),
              ]),
            ),
          ])));
}

Widget chat2() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 1),
          width: 400,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 10),
                  alignment: Alignment.centerLeft,
                  child: Text('Alamat Saya',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 265, top: 5),
                  height: 25,
                  width: 25,
                  child: IconButton(
                    icon: Icon(Icons.arrow_forward_ios),
                    onPressed: () {},
                  ),
                ),
              ]),
            ),
          ])));
}

Widget chat3() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 1),
          width: 400,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 10),
                  alignment: Alignment.centerLeft,
                  child: Text('Kartu/Rekening Bank',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 206, top: 5),
                  height: 25,
                  width: 25,
                  child: IconButton(
                    icon: Icon(Icons.arrow_forward_ios),
                    onPressed: () {},
                  ),
                ),
              ]),
            ),
          ])));
}

Widget chat4() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 1),
          width: 400,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 10),
                  alignment: Alignment.centerLeft,
                  child: Text('Pengaturan Chat',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 235, top: 5),
                  height: 25,
                  width: 25,
                  child: IconButton(
                    icon: Icon(Icons.arrow_forward_ios),
                    onPressed: () {},
                  ),
                ),
              ]),
            ),
          ])));
}

Widget chat5() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 1),
          width: 400,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 10),
                  alignment: Alignment.centerLeft,
                  child: Text('Pengaturan Notifikasi',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 200, top: 5),
                  height: 25,
                  width: 25,
                  child: IconButton(
                    icon: Icon(Icons.arrow_forward_ios),
                    onPressed: () {},
                  ),
                ),
              ]),
            ),
          ])));
}

Widget chat6() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 1),
          width: 400,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 10),
                  alignment: Alignment.centerLeft,
                  child: Text('Privasi',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 300, top: 5),
                  height: 25,
                  width: 25,
                  child: IconButton(
                    icon: Icon(Icons.arrow_forward_ios),
                    onPressed: () {},
                  ),
                ),
              ]),
            ),
          ])));
}

Widget chat7() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 1),
          width: 400,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 10),
                  alignment: Alignment.centerLeft,
                  child: Text('Pusat Bantuan',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 247, top: 5),
                  height: 25,
                  width: 25,
                  child: IconButton(
                    icon: Icon(Icons.arrow_forward_ios),
                    onPressed: () {},
                  ),
                ),
              ]),
            ),
          ])));
}

Widget chat8() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 1),
          width: 400,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 10),
                  alignment: Alignment.centerLeft,
                  child: Text('Tips Dan Trik',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 255, top: 5),
                  height: 25,
                  width: 25,
                  child: IconButton(
                    icon: Icon(Icons.arrow_forward_ios),
                    onPressed: () {},
                  ),
                ),
              ]),
            ),
          ])));
}

Widget chat9() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 1),
          width: 400,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 10),
                  alignment: Alignment.centerLeft,
                  child: Text('Peraturan Komunitas',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 200, top: 5),
                  height: 25,
                  width: 25,
                  child: IconButton(
                    icon: Icon(Icons.arrow_forward_ios),
                    onPressed: () {},
                  ),
                ),
              ]),
            ),
          ])));
}

Widget chat10() {
  return Container(
      child: Container(
          margin: EdgeInsets.only(top: 1),
          width: 400,
          height: 50,
          decoration: BoxDecoration(
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                color: Color.fromARGB(255, 35, 34, 35),
                offset: Offset(0, 1),
                blurRadius: 5,
              ),
            ],
          ),
          child: Column(children: [
            Container(
              child: Row(children: [
                Container(
                  margin: EdgeInsets.only(top: 10, left: 10),
                  alignment: Alignment.centerLeft,
                  child: Text('Informasi',
                      style: TextStyle(
                        fontFamily: 'san-serif',
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 0, 0, 0),
                      )),
                ),
                Container(
                  margin: EdgeInsets.only(left: 280, top: 5),
                  height: 25,
                  width: 25,
                  child: IconButton(
                    icon: Icon(Icons.arrow_forward_ios),
                    onPressed: () {},
                  ),
                ),
              ]),
            ),
          ])));
}

class _Set extends State<Set> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        children: [
          titset(),
          chat(),
          chat2(),
          chat3(),
          titset1(),
          chat4(),
          chat5(),
          chat6(),
          titset2(),
          chat7(),
          chat8(),
          chat9(),
        ],
      ),
    );
  }
}

class titset extends StatelessWidget {
  const titset({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 30,
        child: Stack(
          children: [
            Row(children: [
              Container(
                margin: EdgeInsets.only(left: 10),
                alignment: Alignment.centerLeft,
                child: Text('Acount',
                    style: TextStyle(
                        shadows: [
                          Shadow(
                            blurRadius: 1,
                            color: Colors.black,
                            offset: Offset(1, 1),
                          ),
                        ],
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 55, 51, 51))),
              ),
              Spacer(),
            ])
          ],
        ));
  }
}

class titset1 extends StatelessWidget {
  const titset1({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 30,
        child: Stack(
          children: [
            Row(children: [
              Container(
                margin: EdgeInsets.only(left: 10),
                alignment: Alignment.centerLeft,
                child: Text('settings',
                    style: TextStyle(
                        shadows: [
                          Shadow(
                            blurRadius: 1,
                            color: Colors.black,
                            offset: Offset(1, 1),
                          ),
                        ],
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 55, 51, 51))),
              ),
              Spacer(),
            ])
          ],
        ));
  }
}

class titset2 extends StatelessWidget {
  const titset2({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 30,
        child: Stack(
          children: [
            Row(children: [
              Container(
                margin: EdgeInsets.only(left: 10),
                alignment: Alignment.centerLeft,
                child: Text('help',
                    style: TextStyle(
                        shadows: [
                          Shadow(
                            blurRadius: 1,
                            color: Colors.black,
                            offset: Offset(1, 1),
                          ),
                        ],
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Color.fromARGB(255, 55, 51, 51))),
              ),
              Spacer(),
            ])
          ],
        ));
  }
}
