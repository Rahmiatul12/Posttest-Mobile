import 'package:flutter/material.dart';

import 'halaman2.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: const profile(),
    );
  }
}

class profile extends StatefulWidget {
  const profile({Key? key}) : super(key: key);

  @override
  State<profile> createState() => _profile();
}

Widget boxed3(BuildContext context) {
  return Container(
    alignment: Alignment.bottomRight,
    child: Container(
        width: 400,
        height: 70,
        decoration: BoxDecoration(
          color: Colors.transparent,
        ),
        child: Container(
          alignment: Alignment.centerLeft,
          margin: EdgeInsets.only(left: 10),
          child: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return electronic();
              }));
            },
          ),
        )),
  );
}

Widget boxed4() {
  return Container(
    alignment: Alignment.center,
    child: Container(
      margin: EdgeInsets.only(
        top: 2,
      ),
      width: 400,
      height: 170,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Stack(children: [
        Container(
          alignment: Alignment.topCenter,
          child: Text('My, Profile',
              style: TextStyle(
                fontFamily: 'cursive',
                fontSize: 70,
                color: Color.fromARGB(255, 0, 0, 0),
              )),
        ),
      ]),
    ),
  );
}

class _profile extends State<profile> {
  String firstName = "", lastName = "";

  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();

  List<String> genderList = ["Laki-laki", "Perempuan"];
  String gender = "";
  Widget form() {
    return Container(
        child: Padding(
            padding: EdgeInsets.only(bottom: 10),
            child: Column(children: [
              Container(
                padding: EdgeInsets.only(bottom: 25),
                alignment: Alignment.centerLeft,
                child: TextFormField(
                  controller: firstNameController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Nama Depan ",
                    labelStyle: TextStyle(
                        color: Color.fromARGB(255, 2, 2, 2), fontSize: 20),
                  ),
                ),
              ),
              // SizedBox(height: 5),
              TextFormField(
                controller: lastNameController,
                // maxLines: 4,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Nama Belakang",
                  labelStyle: TextStyle(
                      color: Color.fromARGB(255, 0, 0, 0), fontSize: 20),
                ),
              ),
              for (var item in genderList)
                Row(
                  children: [
                    Radio(
                      value: item,
                      groupValue: gender,
                      onChanged: (v) {
                        setState(() {
                          gender = v.toString();
                        });
                      },
                    ),
                    Text(item),
                  ],
                ),

              ElevatedButton(
                onPressed: () {
                  setState(() {
                    firstName = firstNameController.text;
                    lastName = lastNameController.text;
                  });
                },
                child: Text(
                  "Lihat Data",
                  style: TextStyle(color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  primary: Color.fromARGB(255, 0, 24, 100),
                ),
              ),
            ])));
  }

  Widget Data() {
    return Container(
      alignment: Alignment.topLeft,
      child: Column(children: [
        Text('Profile :',
            style: TextStyle(
              fontFamily: 'cursive',
              fontSize: 30,
              fontWeight: FontWeight.bold,
              color: Color.fromARGB(255, 0, 0, 0),
            )),
        Text("$firstName",
            style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 0, 0, 0))),
        Text("$lastName",
            style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 0, 0, 0))),
        Text(
          "$gender",
          style: TextStyle(
            fontFamily: 'san-serif',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color.fromARGB(255, 0, 0, 0),
          ),
        )
      ]),
    );
  }

  @override
  void dispose() {
    // TODO: implement dispose
    firstNameController.dispose();
    lastNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        alignment: Alignment.topLeft,
        width: lebar,
        height: tinggi,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('produk/bgu.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: ListView(children: <Widget>[
          boxed3(context),
          boxed4(),
          form(),
          Data(),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
          ),
        ]),
      ),
    );
  }
}
