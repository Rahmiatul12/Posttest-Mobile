import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pertemuan7_crud/halaman1.dart';
import 'package:pertemuan7_crud/halaman2.dart';
import 'package:pertemuan7_crud/login.dart';
import 'package:pertemuan7_crud/main.dart';
import 'package:pertemuan7_crud/main_page.dart';
import 'package:pertemuan7_crud/profile.dart';

class halamandet extends StatelessWidget {
  final TextController tc = Get.put(TextController());

  @override
  Widget build(BuildContext context) {
    var appBar2 = AppBar(
      elevation: 0,
      title: Text("Hi ${tc.name.value}",
          style: TextStyle(
            fontFamily: 'san-serif',
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color.fromARGB(255, 255, 255, 255),
          )),
      // actions: [Image.asset('produk/rahmi.png')],
      backgroundColor: Color.fromARGB(255, 241, 182, 239),
    );
    var drawer2 = Drawer(
      child: ListView(
        children: <Widget>[
          ListTile(
            title: Text('Menu Goods'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => electronic(),
                  ));
            },
          ),
          ListTile(
            title: Text('Logout'),
            onTap: () {
              Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => MyHomePage(),
                  ));
            },
          ),
        ],
      ),
    );
    return Scaffold(
      drawer: drawer2,
      appBar: appBar2,
      body: Column(
        children: [
          tabardet(),
        ],
      ),
    );
  }
}

class tabardet extends StatelessWidget {
  const tabardet({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(children: [detail()]),
    );
  }
}

class detail extends StatelessWidget {
  const detail({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Row(
        children: [
          Expanded(
              child: Column(children: [
            Container(
              height: 70,
              width: 70,
              decoration: BoxDecoration(
                  color: Color.fromARGB(255, 255, 255, 255),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black,
                        offset: Offset(0, 5),
                        blurRadius: 10)
                  ]),
              child: Column(children: [
                Container(
                  child: IconButton(
                    icon: Icon(
                      Icons.home,
                      color: Color.fromARGB(235, 5, 5, 5),
                      size: 40,
                    ),
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) {
                        return halaman1();
                      }));
                    },
                  ),
                ),
                Container(
                    child: Text('Home',
                        style: TextStyle(
                          fontFamily: 'san-serif',
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: Color.fromARGB(235, 0, 0, 0),
                        ))),
              ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 50),
              height: 70,
              width: 70,
              decoration: BoxDecoration(
                  color: Color.fromARGB(255, 255, 255, 255),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black,
                        offset: Offset(0, 5),
                        blurRadius: 10)
                  ]),
              child: Column(children: [
                Container(
                  child: IconButton(
                    icon: Icon(
                      Icons.apps,
                      color: Color.fromARGB(235, 0, 0, 0),
                      size: 40,
                    ),
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) {
                        return electronic();
                      }));
                    },
                  ),
                ),
                Container(
                    child: Text('All',
                        style: TextStyle(
                          fontFamily: 'san-serif',
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: Color.fromARGB(235, 0, 0, 0),
                        ))),
              ]),
            ),
            Container(
              margin: EdgeInsets.only(top: 50),
              height: 70,
              width: 70,
              decoration: BoxDecoration(
                  color: Color.fromARGB(255, 255, 255, 255),
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                        color: Colors.black,
                        offset: Offset(0, 5),
                        blurRadius: 10)
                  ]),
              child: Column(children: [
                Container(
                  child: IconButton(
                    icon: Icon(
                      Icons.person,
                      color: Colors.black,
                      size: 40,
                    ),
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) {
                        return Read();
                      }));
                    },
                  ),
                ),
                Container(
                    child: Text('Person',
                        style: TextStyle(
                          fontFamily: 'san-serif',
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: Color.fromARGB(235, 0, 0, 0),
                        ))),
              ]),
            ),
          ])),
          Container(
            height: 495,
            width: 300,
            // margin: EdgeInsets.only(bottom: 100),
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Color.fromARGB(255, 252, 252, 252),
                  blurRadius: 10,
                  spreadRadius: 1,
                ),
              ],
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(30),
                topLeft: Radius.circular(30),
              ),
              image: DecorationImage(
                fit: BoxFit.cover,
                image: AssetImage(
                  'produk/1.png',
                ),
              ),
            ),
          )
        ],
      ),
      Container(
        margin: EdgeInsets.only(top: 20),
        child: Row(children: [
          Container(
            margin: EdgeInsets.only(left: 10),
            child: Text('Handphone',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.black)),
          ),
          Spacer(),
          Container(
              margin: EdgeInsets.only(right: 10),
              child: Text(
                'Rp.4.000.000',
              )),
        ]),
      ),
      Container(
        alignment: Alignment.topLeft,
        child: Text('Terbaru',
            style: TextStyle(fontSize: 15, color: Colors.black)),
      ),
      Container(
          margin: EdgeInsets.only(top: 7),
          child: Row(children: [
            Container(
              child: SizedBox(
                width: 185,
                height: 40,
                child: FlatButton(
                    color: Color.fromARGB(255, 255, 111, 250),
                    onPressed: () {},
                    child: Text(
                      'Beli',
                      style:
                          TextStyle(color: Color.fromARGB(255, 255, 255, 255)),
                    )),
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 1),
              child: SizedBox(
                width: 206,
                height: 40,
                child: FlatButton(
                    color: Color.fromARGB(255, 255, 254, 254),
                    onPressed: () {},
                    child: Text(
                      'Tambah ke Keranjang',
                      style:
                          TextStyle(color: Color.fromARGB(255, 255, 111, 250)),
                    )),
              ),
            ),
          ]))

      // margin: EdgeInsets.only(top: 2),
      // height: 179,
      // width: 400,
      // decoration: BoxDecoration(color: Color.fromARGB(255, 255, 255, 255)),
    ]);
  }
}
