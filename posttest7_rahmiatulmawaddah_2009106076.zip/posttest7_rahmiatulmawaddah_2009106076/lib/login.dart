import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_rx/src/rx_types/rx_types.dart';
import 'package:get/get_state_manager/src/simple/get_controllers.dart';
import 'package:pertemuan7_crud/halaman1.dart';
import 'package:pertemuan7_crud/halaman2.dart';
import 'package:pertemuan7_crud/main.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: const MyHal(),
    );
  }
}

class MyHal extends StatefulWidget {
  const MyHal({Key? key}) : super(key: key);

  @override
  State<MyHal> createState() => _MyHall();
}

Widget boxed3(BuildContext context) {
  return Container(
    alignment: Alignment.bottomRight,
    child: Container(
        width: 400,
        height: 70,
        decoration: BoxDecoration(
          color: Colors.transparent,
        ),
        child: Container(
          alignment: Alignment.centerLeft,
          margin: EdgeInsets.only(left: 10),
          child: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) {
                return MyHomePage();
              }));
            },
          ),
        )),
  );
}

Widget boxed4() {
  return Container(
    alignment: Alignment.center,
    child: Container(
      margin: EdgeInsets.only(
        top: 2,
      ),
      width: 400,
      height: 170,
      decoration: BoxDecoration(
        color: Colors.transparent,
      ),
      child: Stack(children: [
        Container(
          alignment: Alignment.topCenter,
          child: Text('Electronic Goods',
              style: TextStyle(
                fontFamily: 'san-serif',
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Color.fromARGB(255, 0, 0, 0),
              )),
        ),
        Container(
          alignment: Alignment.topCenter,
          margin: EdgeInsets.only(top: 30),
          child: Text('hi, please login',
              style: TextStyle(
                fontFamily: 'cursive',
                fontSize: 70,
                color: Color.fromARGB(255, 0, 0, 0),
              )),
        ),
      ]),
    ),
  );
}

class TextController extends GetxController {
  var name = "".obs;
  final nameEditingController = TextEditingController();
}

class _MyHall extends State<MyHal> {
  String firstName = "", lastName = "";

  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();

  List<String> genderList = ["Laki-laki", "Perempuan"];
  String gender = "";
  Widget form() {
    return Container(
        child: Padding(
            padding: EdgeInsets.only(bottom: 10),
            child: Column(children: [
              Container(
                padding: EdgeInsets.only(bottom: 25),
                alignment: Alignment.centerLeft,
                child: TextFormField(
                  controller: firstNameController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: "Email ",
                    labelStyle: TextStyle(
                        color: Color.fromARGB(255, 2, 2, 2), fontSize: 20),
                  ),
                ),
              ),
              // SizedBox(height: 5),
              TextFormField(
                controller: lastNameController,
                // maxLines: 4,
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  labelText: "Password",
                  labelStyle: TextStyle(
                      color: Color.fromARGB(255, 0, 0, 0), fontSize: 20),
                ),
              ),
              for (var item in genderList)
                Row(
                  children: [
                    Radio(
                      value: item,
                      groupValue: gender,
                      onChanged: (v) {
                        setState(() {
                          gender = v.toString();
                        });
                      },
                    ),
                    Text(item),
                  ],
                ),
              SizedBox(
                height: 30,
                child: ElevatedButton(
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => electronic()));
                  },
                  child: Text(
                    "Login",
                    style: TextStyle(color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    primary: Colors.amber,
                  ),
                ),
              ),

              ElevatedButton(
                onPressed: () {
                  setState(() {
                    firstName = firstNameController.text;
                    lastName = lastNameController.text;
                  });
                },
                child: Text(
                  "Lihat Data",
                  style: TextStyle(color: Colors.white),
                ),
                style: ElevatedButton.styleFrom(
                  primary: Colors.amber,
                ),
              ),
            ])));
  }

  @override
  void dispose() {
    // TODO: implement dispose
    firstNameController.dispose();
    lastNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    var lebar = MediaQuery.of(context).size.width;
    var tinggi = MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
        alignment: Alignment.topLeft,
        width: lebar,
        height: tinggi,
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('produk/bgu.jpg'),
            fit: BoxFit.cover,
          ),
        ),
        child: ListView(children: <Widget>[
          boxed3(context),
          boxed4(),
          LoginPage(),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
          ),
        ]),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextController tc = Get.put(TextController());
  TextEditingController _emailController = TextEditingController();
  TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              margin: EdgeInsets.only(bottom: 16),
              child: TextFormField(
                decoration: InputDecoration(
                  labelText: "Nama",
                  hintText: "Masukkan Nama",
                  prefixIcon: Icon(Icons.nat),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
                controller: tc.nameEditingController,
              ),
            ),
            TextFormField(
              controller: _emailController,
              maxLines: 1,
              keyboardType: TextInputType.emailAddress,
              decoration: InputDecoration(
                labelText: "Email",
                hintText: "Masukkan Email",
                prefixIcon: Icon(Icons.mail),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextFormField(
              controller: _passwordController,
              maxLines: 1,
              keyboardType: TextInputType.visiblePassword,
              decoration: InputDecoration(
                labelText: "Password",
                hintText: "Masukkan Password",
                prefixIcon: Icon(Icons.lock),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () => {
                tc.name.value = tc.nameEditingController.text,
                submit(
                  context,
                  _emailController.text,
                  _passwordController.text,
                )
              },
              child: Text("Login"),
              style: ElevatedButton.styleFrom(
                  primary: Color.fromARGB(255, 0, 24, 95)),
            )
          ],
        ),
      ),
    );
  }

  void submit(BuildContext context, String email, String password) {
    if (email.isEmpty || password.isEmpty) {
      final snackBar = SnackBar(
        duration: const Duration(seconds: 5),
        content: Text("Email dan password harus diisi"),
        backgroundColor: Color.fromARGB(255, 0, 24, 95),
      );

      ScaffoldMessenger.of(context).showSnackBar(snackBar);
      return;
    }

    AlertDialog alert = AlertDialog(
      title: Text("Login Berhasil"),
      content: Container(
        alignment: Alignment.bottomCenter,
        child: Text("Selamat Datang Di Electronic Goods"),
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage('produk/logo.jpg'),
          ),
        ),
      ),
      actions: [
        TextButton(
          child: Text(
            'Masuk',
            style: TextStyle(
              color: Color.fromARGB(255, 0, 24, 95),
            ),
          ),
          onPressed: () => Navigator.push(
              context, MaterialPageRoute(builder: (context) => halaman1())),
        ),
      ],
    );

    showDialog(context: context, builder: (context) => alert);
    return;
  }
}
